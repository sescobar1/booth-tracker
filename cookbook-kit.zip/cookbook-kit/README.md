# Family Cookbook

A free recipe website for your family: snap photos of recipe cards, and everyone you share it with
can read, add and fix recipes.

**Setup instructions:** open `SETUP-GUIDE.html` (download it and open it in your browser), or read them online at
https://sescobar1.github.io/booth-tracker/recipes/friends.html

Short version:
1. Upload everything in this kit to a new GitHub repository and turn on GitHub Pages (Settings -> Pages -> main, / (root)).
2. Make a free Supabase project, and run `setup.sql` in its SQL Editor.
3. Add your sign-in in Supabase (Authentication -> Users -> Add user, Auto Confirm).
4. Paste your Supabase Project URL and anon key into `config.js`.
5. Deploy `supabase-functions/recipe-upload.ts` as an Edge Function named `recipe-upload` with JWT verification off.
