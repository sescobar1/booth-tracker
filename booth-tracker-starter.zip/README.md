# Booth Tracker

A phone-first tracker for booth sales, purchases, rent, mileage, inventory, and taxes.
Your data is saved on the device you use it on. Back it up from Import & backup.
